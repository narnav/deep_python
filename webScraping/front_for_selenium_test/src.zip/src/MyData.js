export const products = [
    { desc: "milk", price: 5 },
    { desc: "toy", price: 15 },
    { desc: "koteg", price: 4 },
  ];