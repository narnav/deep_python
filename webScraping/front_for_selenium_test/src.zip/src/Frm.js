import React, { useState } from "react";

const Frm = () => {
  const [msg, setmsg] = useState("msg");
  const test = () => {
    setmsg("you clicked the button");
  };
  return (
    <div>
      {msg}
      <form action="/login" method="post" name="login">
        Username: <input name="user" type="text" />
        <br />
        Password: <input name="pwd" type="password" />
        <br />
        <br />
        <input
          onClick={() => test()}
          name="Submit"
          type="button"
          value="Submit"
        />
      </form>
    </div>
  );
};

export default Frm;
