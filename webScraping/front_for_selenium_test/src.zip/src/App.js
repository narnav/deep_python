import "./App.css";
import Frm from "./Frm";

function App() {
  return (
    <div className="App">
      <Frm></Frm>
    </div>
  );
}

export default App;
